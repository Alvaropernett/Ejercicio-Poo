public class Chairman extends Congresista {

    public Chairman(int idCongresista, String nombre, String primerApellido, String institucion, String correoElectronico, String telefonoMovil) {
        super(idCongresista, nombre, primerApellido, institucion, correoElectronico, telefonoMovil);
    }
}
